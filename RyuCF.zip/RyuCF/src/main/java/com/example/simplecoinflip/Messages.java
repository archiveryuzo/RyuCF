package com.example.simplecoinflip;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads every message from config.yml (the "messages:" section), swaps in
 * {placeholders} and turns &-color codes into real colors.
 *
 * Example: raw("bet-range", "min", "100", "max", "5000")
 * replaces {min} and {max} in messages.bet-range.
 */
public class Messages {

    // Matches #A71AFF and &#A71AFF
    private static final Pattern HEX = Pattern.compile("&?#([A-Fa-f0-9]{6})");

    private final SimpleCoinflip plugin;

    public Messages(SimpleCoinflip plugin) {
        this.plugin = plugin;
    }

    /** A single message with placeholders filled in. Placeholders come in key, value pairs. */
    public String raw(String key, String... placeholders) {
        String text = plugin.getConfig().getString("messages." + key, "&c[missing message: " + key + "]");
        return apply(text, placeholders);
    }

    /** A multi-line message (a YAML list), like the help screen. */
    public List<String> list(String key, String... placeholders) {
        List<String> out = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("messages." + key)) {
            out.add(apply(line, placeholders));
        }
        return out;
    }

    public String prefix() {
        return raw("prefix");
    }

    /** The word for a side ("Heads" or "Tails"), so server owners can translate it. */
    public String side(CoinflipManager.Side side) {
        return raw(side == CoinflipManager.Side.HEADS ? "heads" : "tails");
    }

    /** Sends a message with the plugin prefix in front. */
    public void send(CommandSender receiver, String key, String... placeholders) {
        receiver.sendMessage(prefix() + raw(key, placeholders));
    }

    private String apply(String text, String... placeholders) {
        for (int i = 0; i + 1 < placeholders.length; i += 2) {
            text = text.replace("{" + placeholders[i] + "}", placeholders[i + 1]);
        }
        return colorize(text);
    }

    /** Turns #RRGGBB (or &#RRGGBB) into hex colors, then &-codes into normal colors. */
    private String colorize(String text) {
        Matcher matcher = HEX.matcher(text);
        StringBuilder out = new StringBuilder();
        while (matcher.find()) {
            String color = net.md_5.bungee.api.ChatColor.of("#" + matcher.group(1)).toString();
            matcher.appendReplacement(out, Matcher.quoteReplacement(color));
        }
        matcher.appendTail(out);
        return ChatColor.translateAlternateColorCodes('&', out.toString());
    }
}
