package com.example.simplecoinflip;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class SimpleCoinflip extends JavaPlugin {

    private Economy economy;
    private CoinflipManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        if (!setupEconomy()) {
            getLogger().severe("Vault or an economy plugin (like EssentialsX) was not found. Disabling.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        Messages messages = new Messages(this);
        CoinflipAnimation animation = new CoinflipAnimation(this, messages);
        getServer().getPluginManager().registerEvents(animation, this);
        manager = new CoinflipManager(this, economy, messages, animation);

        CoinflipGui gui = new CoinflipGui(manager, messages);
        getServer().getPluginManager().registerEvents(gui, this);

        CoinflipCommand command = new CoinflipCommand(this, manager, gui, messages);
        getCommand("coinflip").setExecutor(command);
        getCommand("coinflip").setTabCompleter(command);

        getLogger().info("RyuCF enabled.");
    }

    @Override
    public void onDisable() {
        // Give everyone their money back if the server stops with open offers.
        if (manager != null) {
            manager.refundAll();
        }
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp =
                getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        economy = rsp.getProvider();
        return economy != null;
    }
}
