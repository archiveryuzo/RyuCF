package com.example.simplecoinflip;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CoinflipCommand implements CommandExecutor, TabCompleter {

    private final SimpleCoinflip plugin;
    private final CoinflipManager manager;
    private final CoinflipGui gui;
    private final Messages messages;

    public CoinflipCommand(SimpleCoinflip plugin, CoinflipManager manager, CoinflipGui gui, Messages messages) {
        this.plugin = plugin;
        this.manager = manager;
        this.gui = gui;
        this.messages = messages;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Console can't hold money or flip coins, so only players are allowed.
        if (!(sender instanceof Player player)) {
            sender.sendMessage(messages.raw("players-only"));
            return true;
        }
        if (!player.hasPermission("simplecoinflip.use")) {
            messages.send(player, "no-permission");
            return true;
        }
        if (args.length == 0) {
            gui.open(player);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create" -> handleCreate(player, args);
            case "join" -> {
                if (args.length < 2) {
                    messages.send(player, "usage-join");
                } else {
                    manager.join(player, args[1]);
                }
            }
            case "cancel" -> manager.cancel(player);
            case "list" -> handleList(player);
            case "menu" -> gui.open(player);
            case "help" -> sendHelp(player);
            case "reload" -> {
                if (player.hasPermission("simplecoinflip.reload")) {
                    plugin.reloadConfig();
                    messages.send(player, "config-reloaded");
                } else {
                    messages.send(player, "no-permission");
                }
            }
            default -> sendHelp(player);
        }
        return true;
    }

    private void handleCreate(Player player, String[] args) {
        if (args.length < 2) {
            messages.send(player, "usage-create");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(args[1]);
        } catch (NumberFormatException e) {
            messages.send(player, "invalid-number", "input", args[1]);
            return;
        }
        // Rejects NaN, infinity, zero and negatives (negative bets would be an exploit).
        if (Double.isNaN(amount) || Double.isInfinite(amount) || amount <= 0) {
            messages.send(player, "must-be-positive");
            return;
        }

        CoinflipManager.Side side = CoinflipManager.Side.HEADS;
        if (args.length >= 3) {
            String pick = args[2].toLowerCase(Locale.ROOT);
            if (pick.equals("heads") || pick.equals("h")) {
                side = CoinflipManager.Side.HEADS;
            } else if (pick.equals("tails") || pick.equals("t")) {
                side = CoinflipManager.Side.TAILS;
            } else {
                messages.send(player, "invalid-side");
                return;
            }
        }

        manager.create(player, amount, side);
    }

    private void handleList(Player player) {
        if (manager.getOffers().isEmpty()) {
            messages.send(player, "list-empty");
            return;
        }
        player.sendMessage(messages.raw("list-header"));
        for (CoinflipManager.Offer offer : manager.getOffers()) {
            player.sendMessage(messages.raw("list-entry",
                    "player", offer.creatorName(),
                    "amount", manager.format(offer.amount()),
                    "side", messages.side(offer.side())));
        }
    }

    private void sendHelp(Player player) {
        for (String line : messages.list("help")) {
            player.sendMessage(line);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("create", "join", "cancel", "list", "menu", "help")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("join")) {
            for (CoinflipManager.Offer offer : manager.getOffers()) {
                if (offer.creatorName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    out.add(offer.creatorName());
                }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("create")) {
            for (String s : List.of("heads", "tails")) {
                if (s.startsWith(args[2].toLowerCase(Locale.ROOT))) out.add(s);
            }
        }
        return out;
    }
}
