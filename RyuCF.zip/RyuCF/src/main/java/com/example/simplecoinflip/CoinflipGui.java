package com.example.simplecoinflip;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The /cf menu: a chest where every open bet is shown as the creator's head.
 * Click someone else's head to join their flip. Click your own head to cancel it.
 */
public class CoinflipGui implements Listener {

    private static final int SIZE = 54;          // 6 rows
    private static final int MAX_OFFERS = 45;    // first 5 rows hold bets
    private static final int EMPTY_SLOT = 22;
    private static final int CREATE_SLOT = 49;
    private static final int REFRESH_SLOT = 53;

    private final CoinflipManager manager;
    private final Messages messages;

    public CoinflipGui(CoinflipManager manager, Messages messages) {
        this.manager = manager;
        this.messages = messages;
    }

    /** Marks an inventory as ours and remembers which offer sits in which slot. */
    private static class GuiHolder implements InventoryHolder {
        private Inventory inventory;
        private final Map<Integer, CoinflipManager.Offer> offersBySlot = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    public void open(Player player) {
        GuiHolder holder = new GuiHolder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, messages.raw("gui-title"));
        holder.inventory = inv;
        fill(holder, player);
        player.openInventory(inv);
        manager.playSound(player, Sound.BLOCK_ENDER_CHEST_OPEN, 0.8f, 1.0f);
    }

    private void fill(GuiHolder holder, Player viewer) {
        Inventory inv = holder.inventory;
        inv.clear();
        holder.offersBySlot.clear();

        int slot = 0;
        for (CoinflipManager.Offer offer : manager.getOffers()) {
            if (slot >= MAX_OFFERS) {
                break;
            }
            inv.setItem(slot, makeHead(offer, viewer));
            holder.offersBySlot.put(slot, offer);
            slot++;
        }

        if (holder.offersBySlot.isEmpty()) {
            inv.setItem(EMPTY_SLOT, named(Material.BARRIER,
                    messages.raw("gui-empty-name"),
                    List.of(messages.raw("gui-empty-lore"))));
        }

        ItemStack filler = named(Material.PURPLE_STAINED_GLASS_PANE, " ", List.of());
        for (int i = MAX_OFFERS; i < SIZE; i++) {
            inv.setItem(i, filler);
        }

        inv.setItem(CREATE_SLOT, named(Material.EMERALD,
                messages.raw("gui-create-name"),
                messages.list("gui-create-lore")));
        inv.setItem(REFRESH_SLOT, named(Material.CLOCK,
                messages.raw("gui-refresh-name"),
                List.of(messages.raw("gui-refresh-lore"))));
    }

    private ItemStack makeHead(CoinflipManager.Offer offer, Player viewer) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(Bukkit.getOfflinePlayer(offer.creator()));
        meta.setDisplayName(messages.raw("gui-head-name", "player", offer.creatorName()));

        List<String> lore = new ArrayList<>();
        lore.add(messages.raw("gui-head-bet", "amount", manager.format(offer.amount())));
        lore.add(messages.raw("gui-head-side", "side", messages.side(offer.side())));
        lore.add("");
        if (offer.creator().equals(viewer.getUniqueId())) {
            lore.add(messages.raw("gui-head-cancel"));
        } else {
            lore.add(messages.raw("gui-head-join"));
        }
        meta.setLore(lore);
        head.setItemMeta(meta);
        return head;
    }

    private ItemStack named(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        if (!lore.isEmpty()) {
            meta.setLore(lore);
        }
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof GuiHolder holder)) {
            return;
        }
        // Nobody can take items out of the menu.
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= SIZE) {
            return; // clicked in their own inventory
        }

        if (slot == CREATE_SLOT) {
            player.closeInventory();
            messages.send(player, "gui-create-chat");
            return;
        }
        if (slot == REFRESH_SLOT) {
            fill(holder, player);
            return;
        }

        CoinflipManager.Offer offer = holder.offersBySlot.get(slot);
        if (offer == null) {
            return;
        }

        if (offer.creator().equals(player.getUniqueId())) {
            manager.cancel(player);
            fill(holder, player);
        } else {
            player.closeInventory();
            manager.join(player, offer.creatorName());
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof GuiHolder) {
            event.setCancelled(true);
        }
    }
}
