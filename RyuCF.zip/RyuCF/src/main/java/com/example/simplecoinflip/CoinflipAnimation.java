package com.example.simplecoinflip;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The rolling-coin screen shown to both players when a flip happens.
 *
 * A gold ingot means Heads and an iron ingot means Tails. The coin flips back and forth,
 * slowing down, and lands on the real result. Then the winner sees an emerald block and
 * the loser sees a redstone block.
 *
 * This is only a show: the result is decided and the money is paid BEFORE it starts.
 */
public class CoinflipAnimation implements Listener {

    private static final int SIZE = 27;       // 3 rows
    private static final int COIN_SLOT = 13;  // middle of the chest

    // Ticks to wait after each frame (20 ticks = 1 second). Starts fast, then slows down like a real coin.
    private static final int[] DELAYS = {2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 4, 5, 6, 7, 8, 10};

    private final SimpleCoinflip plugin;
    private final Messages messages;

    public CoinflipAnimation(SimpleCoinflip plugin, Messages messages) {
        this.plugin = plugin;
        this.messages = messages;
    }

    /** Marks an inventory as the animation screen so clicks on it can be blocked. */
    private static class AnimHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    /**
     * @param viewers  the players who watch (the joiner, and the creator if online)
     * @param result   which side the coin really landed on
     * @param winnerId who won
     * @param payout   the winner's payout, already formatted (shown on the emerald block)
     * @param onReveal runs at the moment of the reveal (used to send the chat result)
     */
    public void play(List<Player> viewers, CoinflipManager.Side result, UUID winnerId, String payout, Runnable onReveal) {
        // Open the screens on the next tick: opening a menu while a click is still being handled can glitch.
        Bukkit.getScheduler().runTask(plugin, () -> {
            Map<Player, Inventory> views = new LinkedHashMap<>();
            for (Player player : viewers) {
                if (!player.isOnline()) {
                    continue;
                }
                AnimHolder holder = new AnimHolder();
                Inventory inv = Bukkit.createInventory(holder, SIZE, messages.raw("anim-title"));
                holder.inventory = inv;

                ItemStack filler = named(Material.PURPLE_STAINED_GLASS_PANE, " ", List.of());
                for (int i = 0; i < SIZE; i++) {
                    inv.setItem(i, filler);
                }
                player.openInventory(inv);
                views.put(player, inv);
            }

            // Decide which side shows on each frame so the LAST frame is the real result.
            int frames = DELAYS.length;
            CoinflipManager.Side[] sides = new CoinflipManager.Side[frames];
            for (int k = 0; k < frames; k++) {
                sides[k] = ((frames - 1 - k) % 2 == 0) ? result : result.opposite();
            }

            showFrame(views, sides, 0, winnerId, payout, onReveal);
        });
    }

    private void showFrame(Map<Player, Inventory> views, CoinflipManager.Side[] sides, int frame,
                           UUID winnerId, String payout, Runnable onReveal) {
        if (frame >= sides.length) {
            // The coin has landed. Wait a moment, then show who won.
            Bukkit.getScheduler().runTaskLater(plugin, () -> reveal(views, winnerId, payout, onReveal), 8L);
            return;
        }

        ItemStack coin = coin(sides[frame]);
        for (Map.Entry<Player, Inventory> entry : views.entrySet()) {
            entry.getValue().setItem(COIN_SLOT, coin);
            // A little "tick" that gets higher as the coin spins.
            playSound(entry.getKey(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.8f, 0.8f + frame * 0.04f);
        }

        Bukkit.getScheduler().runTaskLater(plugin,
                () -> showFrame(views, sides, frame + 1, winnerId, payout, onReveal),
                DELAYS[frame]);
    }

    private void reveal(Map<Player, Inventory> views, UUID winnerId, String payout, Runnable onReveal) {
        onReveal.run();

        for (Map.Entry<Player, Inventory> entry : views.entrySet()) {
            Player player = entry.getKey();
            Inventory inv = entry.getValue();
            boolean won = player.getUniqueId().equals(winnerId);

            Material pane = won ? Material.LIME_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE;
            ItemStack filler = named(pane, " ", List.of());
            for (int i = 0; i < SIZE; i++) {
                inv.setItem(i, filler);
            }

            // Emerald block = you won. Redstone block = you lost.
            Material block = won ? Material.EMERALD_BLOCK : Material.REDSTONE_BLOCK;
            inv.setItem(COIN_SLOT, named(block,
                    messages.raw(won ? "anim-win" : "anim-lose"),
                    List.of(messages.raw(won ? "anim-win-lore" : "anim-lose-lore", "payout", payout))));

            playSound(player, won ? Sound.ENTITY_PLAYER_LEVELUP : Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
        }

        // Close the screen after a couple of seconds (only if the player is still looking at it).
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (Map.Entry<Player, Inventory> entry : views.entrySet()) {
                Player player = entry.getKey();
                if (player.isOnline() && player.getOpenInventory().getTopInventory() == entry.getValue()) {
                    player.closeInventory();
                }
            }
        }, 50L);
    }

    private ItemStack coin(CoinflipManager.Side side) {
        if (side == CoinflipManager.Side.HEADS) {
            return named(Material.GOLD_INGOT, messages.raw("anim-heads"), List.of());
        }
        return named(Material.IRON_INGOT, messages.raw("anim-tails"), List.of());
    }

    private ItemStack named(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        if (!lore.isEmpty()) {
            meta.setLore(lore);
        }
        item.setItemMeta(meta);
        return item;
    }

    private void playSound(Player player, Sound sound, float volume, float pitch) {
        if (player.isOnline() && plugin.getConfig().getBoolean("sounds", true)) {
            player.playSound(player.getLocation(), sound, volume, pitch);
        }
    }

    // Nobody can grab items out of the animation screen.
    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof AnimHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof AnimHolder) {
            event.setCancelled(true);
        }
    }
}
