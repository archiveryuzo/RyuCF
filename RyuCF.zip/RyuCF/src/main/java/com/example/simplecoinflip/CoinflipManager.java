package com.example.simplecoinflip;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class CoinflipManager {

    public enum Side {
        HEADS, TAILS;

        public Side opposite() {
            return this == HEADS ? TAILS : HEADS;
        }
    }

    /** One open bet waiting for an opponent. The creator's money is already held. */
    public record Offer(UUID creator, String creatorName, double amount, Side side, BukkitTask expiryTask) {
    }

    private final SimpleCoinflip plugin;
    private final Economy economy;
    private final Messages messages;
    private final CoinflipAnimation animation;
    // Keyed by the creator's UUID: one offer per player. LinkedHashMap keeps /cf list in order.
    private final Map<UUID, Offer> offers = new LinkedHashMap<>();

    public CoinflipManager(SimpleCoinflip plugin, Economy economy, Messages messages, CoinflipAnimation animation) {
        this.plugin = plugin;
        this.economy = economy;
        this.messages = messages;
        this.animation = animation;
    }

    public Collection<Offer> getOffers() {
        return offers.values();
    }

    public void create(Player player, double amount, Side side) {
        double min = plugin.getConfig().getDouble("min-bet", 100);
        double max = plugin.getConfig().getDouble("max-bet", 1_000_000);

        if (offers.containsKey(player.getUniqueId())) {
            messages.send(player, "already-open");
            return;
        }
        if (amount < min || amount > max) {
            messages.send(player, "bet-range", "min", format(min), "max", format(max));
            return;
        }
        if (!economy.has(player, amount)) {
            messages.send(player, "not-enough-money");
            return;
        }

        EconomyResponse response = economy.withdrawPlayer(player, amount);
        if (!response.transactionSuccess()) {
            messages.send(player, "withdraw-failed", "error", String.valueOf(response.errorMessage));
            return;
        }

        int expireSeconds = plugin.getConfig().getInt("offer-expire-seconds", 120);
        UUID id = player.getUniqueId();

        BukkitTask expiry = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Offer expired = offers.remove(id);
            if (expired != null) {
                refund(expired);
                Player p = Bukkit.getPlayer(id);
                if (p != null) {
                    messages.send(p, "offer-expired", "amount", format(expired.amount()));
                }
            }
        }, expireSeconds * 20L);

        offers.put(id, new Offer(id, player.getName(), amount, side, expiry));

        messages.send(player, "offer-created",
                "amount", format(amount),
                "side", messages.side(side),
                "seconds", String.valueOf(expireSeconds));
        Bukkit.broadcastMessage(messages.prefix() + messages.raw("offer-announce",
                "player", player.getName(),
                "amount", format(amount),
                "side", messages.side(side)));
    }

    public void join(Player joiner, String creatorName) {
        Offer offer = findOffer(creatorName);
        if (offer == null) {
            messages.send(joiner, "no-such-offer");
            return;
        }
        if (offer.creator().equals(joiner.getUniqueId())) {
            messages.send(joiner, "cannot-join-own");
            return;
        }
        if (!economy.has(joiner, offer.amount())) {
            messages.send(joiner, "join-not-enough", "amount", format(offer.amount()));
            return;
        }

        EconomyResponse response = economy.withdrawPlayer(joiner, offer.amount());
        if (!response.transactionSuccess()) {
            messages.send(joiner, "withdraw-failed", "error", String.valueOf(response.errorMessage));
            return;
        }

        // The offer is taken: remove it and stop its expiry timer.
        offers.remove(offer.creator());
        offer.expiryTask().cancel();

        // The actual coin flip.
        Side result = ThreadLocalRandom.current().nextBoolean() ? Side.HEADS : Side.TAILS;
        boolean creatorWins = result == offer.side();

        OfflinePlayer creator = Bukkit.getOfflinePlayer(offer.creator());
        OfflinePlayer winner = creatorWins ? creator : joiner;
        String winnerName = creatorWins ? offer.creatorName() : joiner.getName();
        String loserName = creatorWins ? joiner.getName() : offer.creatorName();

        double pot = offer.amount() * 2;
        double tax = pot * (plugin.getConfig().getDouble("tax-percent", 5) / 100.0);
        double payout = pot - tax;

        economy.depositPlayer(winner, payout);

        // The result is already decided and paid. Everything below is just how it gets shown.
        Player creatorPlayer = creator.getPlayer();

        String message = messages.prefix() + messages.raw("result",
                "result", messages.side(result),
                "winner", winnerName,
                "loser", loserName,
                "payout", format(payout));

        // Sends the result to chat (to everyone, or just the two players, depending on config).
        Runnable announce = () -> {
            if (plugin.getConfig().getBoolean("broadcast-results", true)) {
                Bukkit.broadcastMessage(message);
            } else {
                joiner.sendMessage(message);
                if (creatorPlayer != null) {
                    creatorPlayer.sendMessage(message);
                }
            }
        };

        if (plugin.getConfig().getBoolean("flip-animation", true)) {
            // Rolling coin screen first; the chat message and win/lose sounds come at the reveal.
            List<Player> viewers = new ArrayList<>();
            viewers.add(joiner);
            if (creatorPlayer != null) {
                viewers.add(creatorPlayer);
            }
            animation.play(viewers, result, winner.getUniqueId(), format(payout), announce);
        } else {
            // Animation turned off: show the result right away.
            announce.run();
            Player winnerPlayer = creatorWins ? creatorPlayer : joiner;
            Player loserPlayer = creatorWins ? joiner : creatorPlayer;
            playSound(winnerPlayer, Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            playSound(loserPlayer, Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
        }
    }

    public void cancel(Player player) {
        Offer offer = offers.remove(player.getUniqueId());
        if (offer == null) {
            messages.send(player, "no-own-offer");
            return;
        }
        offer.expiryTask().cancel();
        refund(offer);
        messages.send(player, "offer-cancelled", "amount", format(offer.amount()));
    }

    /** Called when the plugin shuts down so nobody loses held money. */
    public void refundAll() {
        for (Offer offer : offers.values()) {
            offer.expiryTask().cancel();
            refund(offer);
        }
        offers.clear();
    }

    private void refund(Offer offer) {
        economy.depositPlayer(Bukkit.getOfflinePlayer(offer.creator()), offer.amount());
    }

    private Offer findOffer(String creatorName) {
        for (Offer offer : offers.values()) {
            if (offer.creatorName().equalsIgnoreCase(creatorName)) {
                return offer;
            }
        }
        return null;
    }

    /** Plays a sound to one player, if they're online and sounds are enabled in config. */
    public void playSound(Player player, Sound sound, float volume, float pitch) {
        if (player != null && plugin.getConfig().getBoolean("sounds", true)) {
            player.playSound(player.getLocation(), sound, volume, pitch);
        }
    }

    public String format(double amount) {
        return economy.format(amount);
    }
}
